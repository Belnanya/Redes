package src.Redes;


import java.io.IOException;


//Clase principal que hará uso del servidor
public class MainServidor
{
    public static void main(String[] args) throws IOException {
        Servidor serv = new Servidor(); //Se crea el servidor

        System.out.println("Iniciando servidor\n");
        //serv.startServer(); //Se inicia el servidor
        /*while (true) {
            try {
                System.out.println("Entro para aceptar clientes");
                Socket cliente = socket.accept();
                System.out.println ("Conectado con cliente de " + cliente.getInetAddress());
                MiClase a= new MiClase(cliente);
                Thread hilo = new Thread(a);
                a.start();
                algo asi.
            }*/
}
